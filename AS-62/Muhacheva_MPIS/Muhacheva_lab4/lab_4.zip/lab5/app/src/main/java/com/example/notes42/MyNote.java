package com.example.notes42;

public class MyNote {
    String name;
    String description;
    public MyNote(String name,String description)
    {
        this.name = name;
        this.description = description;
    }
}
